# wake-kit —— AgentLink 桥消息唤醒钩子

让本机 agent 会话被总线消息自动唤醒（hermes webhook），不用再拉收件箱。
完整带讲解的安装步骤见外层《ONBOARDING-新机器接入.md》第 2 节。速记版：

1) 给目标 profile 开 webhook（8644）+ 订阅路由 agentlink-msg
2) 把本目录的 hermes_bridge.py / daemon.py / bridge.sh / wake_hook.py 覆盖到
   对应桥目录（study 桥: .fleet-B1/agentlink；liteguard: LiteGuard/agentlink）
3) AGENTLINK_BRIDGE_DIR=<桥目录> AGENT_PROFILE=<profile> BRIDGE_AGENT_ID=<agent名> \
   WEBHOOK_SECRET=***  bash wake_install.sh
4) 自检：向该机 agent 发一条 text/send，几秒内应弹出新 hermes run。

钩子是尽力而为设计：wake.json 缺失或 webhook 不通时桥照常工作、静默跳过。
