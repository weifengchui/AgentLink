# AgentLink

局域网内多台机器上 **AI Agent 之间** 的通信总线。只为程序服务，不为人聊天。

一台机器跑一个常驻小进程（Node），本机 Agent 通过 `127.0.0.1` 的 HTTP/WS 接口收发消息与文件；
各机器的 Node 之间自动发现、建立 WebSocket 连接，把消息可靠地送到对端或广播给所有节点。

- 设计文档：[`docs/设计方案.md`](docs/设计方案.md)
- 协议规范：[`docs/protocol.md`](docs/protocol.md)
- 部署指南：[`docs/部署.md`](docs/部署.md)
- 定位：小、轻、稳、零配置
- 不做：任务板、角色体系、工作流编排、人类聊天 UI、公网穿透

## 状态

全部里程碑已完成：单文件 ~1.5 MB 的 Rust 常驻进程，包含发现、连接、可靠消息、文件传输、安全与部署脚本。

> v0.4.9：Windows 开机自启内置——`agentlink autostart` 在当前用户"启动"文件夹写入
> `AgentLink.vbs` 隐藏窗口启动脚本（无需管理员），`启动.bat` 双击时自动静默注册；
> `run --no-open` 后台拉起不弹浏览器。Linux 侧仍用 `deploy/install-systemd.sh`。
>
> v0.4.17：总览页重构——快捷发送面板移除，替换为「消息星图」全屏面板（`/v1/starmap` iframe）；
> 对话消息按话题链可视化，悬停/点选节点、agent、消息卡片只显示相关连线与目的地；
> 历史记录条目新增 `reply_to` 透传，`/v1/history/search` 返回回复链元数据。
> 同版含第二轮 UI 修订：配色保存 HTTP 415 修复（fetch 自动补 Content-Type + 后端宽容提取）；
> 双层胶囊配色体系——节点深色外托（hsl 46%/30%，按 node_id 散列、改名不漂移）+ 内嵌靠右亮色 agent 小胶囊（58%/72%），
> 左侧留 14px 粗圆弧，对话记录/设置页/星图三处统一；星图节点圆圈内显示节点名（改名 ≤1s 广播生效）、不再显示 node_id、
> 站台动态环布局默认整体居中；星图 HUD 紧凑化；设置页配色区改 flex 防变形。
>
> v0.4.10：数据目录默认外置（Windows `%LOCALAPPDATA%\AgentLink\data`、Linux `~/.local/share/agentlink`），
> 不再放软件目录里以免升级覆盖；`agentlink.json` 的 `data_dir` 可按机器各自改为绝对路径，
> 相对路径以配置文件目录为基准。发布包新增 `SKILL-agent-registration.md`（Agent 上线注册技能，
> 每台机器的 Agent 都应先学习并执行它）。

| 阶段 | 内容 | 状态 |
|------|------|------|
| M0 | 骨架：配置 / 日志 / CLI / health | ✅ |
| M1 | UDP 发现 + WS 建连 + 心跳 + `/v1/peers`（含静态 peers） | ✅ |
| M2 | 消息：信封 / 点对点 / 广播 / `/v1/send` + WS 订阅 | ✅ |
| M3 | 可靠性：ACK / 重试 / 去重 / 离线暂存 | ✅ |
| M4 | 文件传输：分块 / 校验 / 续传位 / 大小与文件名安全 | ✅ |
| M5 | 安全（token/HMAC/防重放）+ 服务化打包脚本 | ✅ |
| M6 | mDNS（feature 开关）/ 静态 peers / 指标 / 文档 | ✅ |

## 构建

```bash
cargo build --release
# 产物：target/release/agentlink（Linux/macOS）或 agentlink.exe（Windows）
# release 体积约 1.5 MB（LTO + strip + opt-level=z）

# 可选：启用 mDNS 发现（需在配置 discovery.methods 加入 "mdns"）
cargo build --release --features mdns
```

## 使用

```bash
# 1) 主机：创建配置（自动生成随机 node_id 与 cluster_token）
agentlink init --name agent-PC-A
#    init 会直接提示：其他机器运行 agentlink join <token> 一键配对

# 2) 其他机器：自动配对（无需手改 agentlink.json）
agentlink join <token> --name agent-PC-B

# 免密快速测试（局域网互信，跳过 token 校验）
agentlink init --open        # 或 agentlink join <token> --open

# 查看本机 cluster_token
agentlink token

# 3) 运行
agentlink run

# 4) 查看状态与节点
curl http://127.0.0.1:8765/v1/health
curl -H 'X-Auth-Token: <local token>' http://127.0.0.1:8765/v1/status
curl -H 'X-Auth-Token: <local token>' http://127.0.0.1:8765/v1/peers
```

## 本地接口

| 方法 | 路径 | 鉴权 | 说明 |
|------|------|------|------|
| GET | `/v1/health` | 无 | 存活探针 |
| GET | `/v1/status` | `X-Auth-Token` | 节点状态（peers / pending_acks / offline_queue / local_pending / active_transfers） |
| GET | `/v1/peers` | `X-Auth-Token` | 已知节点及在线状态 |
| POST | `/v1/send` | `X-Auth-Token` | 发消息（点对点 / `"*"` 广播）；body 无需 Content-Type |
| POST | `/v1/send-file` | `X-Auth-Token` | 传本地文件（`to` + `file_path`） |
| POST | `/v1/send-file-upload` | `X-Auth-Token` | 上传字节流发文件（`?to=` + 头 `X-File-Name`），供 `/web` 页面使用；上限 = `files.max_file_size`（默认 100 MB）。**v0.4.13 前实际卡在 2 MiB**（axum 默认体上限），超 2 MiB 会报纯文本 413 |
| POST | `/v1/ack-inbox` | `X-Auth-Token` | 确认已读的本机消息 |
| GET/POST/DELETE | `/v1/agents` | `X-Auth-Token` | 注册/查看/注销本机 Agent（多 Agent，能力标签） |
| GET | `/v1/fleet/agents` | `X-Auth-Token` | 全网 Agent 目录（节点间自动同步） |
| GET/PUT | `/v1/config` | `X-Auth-Token` | 查看/修改配置（掩码显示；名称/标签即时生效） |
| GET | `/v1/history` | `X-Auth-Token` | 最近对话记录（环形缓冲） |
| GET | `/v1/starmap` | 无需令牌（HTML 页） | 消息星图全屏页：总览内嵌 iframe 同源展示，数据源 /v1/history/search + 拓扑接口（v0.4.17+） |
| GET | `/v1/history/stats` | `X-Auth-Token` | 对话记录体积统计（活动/归档/合计、滚动阈值，v0.4.15+） |
| GET | `/v1/history/export?format=json\|text&scope=all\|active\|archive:<名>` | `X-Auth-Token` | 导出对话记录（带下载名；只读，不动源文件，v0.4.15+） |
| GET | `/v1/history/search?from=&to=&who=&direction=&kind=&q=&since=&until=&limit=&max_mb=&scope=` | `X-Auth-Token` | 对话记录检索：按收发方/方向/类型/关键词/时间过滤（v0.4.15+） |
| GET/PUT | `/v1/colors` | `X-Auth-Token` | 节点与 Agent 的标识颜色：自动配色 + 手动覆盖（v0.4.15+） |
| GET | `/web` | 无（token 页内输入） | **人工可看页面**（V1 风格）：总览/节点/Agent/对话/发送/配置；token 只存会话不进 URL |
| WS | `/v1/ws?token=…&client=…` | query token | 订阅本机入站消息（`client` 即 agent_id，按 `to_agent` 定向投递）与 join/leave 事件 |
| WS | `/peer/ws` | cluster token（握手） | 对等节点消息连接 |
| WS | `/peer/file/ws` | cluster token（握手） | 对等节点文件传输连接 |

```bash
# 发消息（点对点 or 广播）
curl -X POST http://127.0.0.1:8765/v1/send -H "X-Auth-Token: $TOKEN" -d \
  '{"to":"agent-B","type":"text","action":"send","payload":{"content":"hello"}}'
curl -X POST http://127.0.0.1:8765/v1/send -H "X-Auth-Token: $TOKEN" -d \
  '{"to":"*","type":"text","action":"broadcast","payload":{"content":"notify all"}}'

# 发文件
curl -X POST http://127.0.0.1:8765/v1/send-file -H "X-Auth-Token: $TOKEN" -d \
  '{"to":"agent-B","file_path":"C:\\data\\report.pdf"}'
```

## 架构

- **发现**：UDP 广播（默认）→ mDNS（`--features mdns`）→ 静态 peers（兜底）
- **拓扑**：Mesh 全互联 WebSocket，`node_id` 字典序小的主动拨号，每对一条连接
- **可靠性**：点对点 at-least-once（ACK + 有界重试 + 离线暂存 TTL），广播 at-most-once
- **消息**：统一 JSON 信封（含 `from_agent`/`to_agent`），多 Agent 一机并存、Agent 间对话，`payload` 完全透传
- **Agent 目录**：注册能力标签，节点间 `ctrl/agents_update` 同步，`/v1/fleet/agents` 看全网
- **人工视图**：`/web` 页面 + `/v1/history` 看节点 / Agent / 双方聊了啥
- **机器标签**：`tags` 进 `/v1/peers`（A：能力标签）
- **文件**：独立 `/peer/file/ws` 连接，分块 + SHA-256 校验 + `recv_dir` 沙箱
- **安全**：`strict`（共享 `cluster_token` + HMAC 握手/帧签名 + 时间窗防重放）/ `open`

## 端口

- `8765`（`listen_port`）：本地 API + 对等节点 WebSocket
- `8766`（`broadcast_port`）：UDP 发现广播

首次运行请在防火墙放行这两个端口（见 [`docs/部署.md`](docs/部署.md)）。
## 版本提要
- **v0.4.12**：消息可靠性持久化——队列（inbox/offline/pending/local/seen）以
  `data_dir/journal.jsonl` 追加日志（每条 fsync，重启全量回放，过期离线件自动丢弃）；
  agent 注册表原子快照 `data_dir/agents.json`；`history.jsonl` 重启回放、超 16MB 轮转。
  开关：`delivery.persist=false` 关日志（临时测试节点）、`delivery.agent_stale_ttl_seconds`
  清理久未重注册的离线 agent（默认 3600，0 关闭）。`/v1/status` 新增 inbox/durable 字段。
  web 控制台：节点/Agent 表头排序、消息展开与复制、选中文本不再被自动刷新打断、toast 提示。
- **v0.4.11**：`init/join --force` 保留 node_id/token/data_dir（堵死身份漂移事故）；
  fleet agents 在线状态联动节点（幽灵在线消除）；web 节点列表加「本机」标记与离线节点「遗忘」
  按钮（`DELETE /v1/peers/<id>/forget`，持久化 data_dir/forgotten_peers.json，真实握手自动解禁）。

## v0.4.15 发布物说明

- 对话记录不再丢：活动文件写满或超龄后**整份搬进** `data/history_archive/`（按滚动时刻命名），
  旧的单份 `.1` 备份（覆盖即删记录）已废弃；启动时自动收编遗留 `.1` 为 `history-legacy.jsonl`。
  `history.archive_keep=0`（默认）= 归档永久保留，不自动删。
- 界面导出：对话页与总览页显示「当前/归档/合计体积 + 滚动阈值」，只读导出 JSONL / 可读文本
  （可选含归档或仅当前）；**当前**活动文件达到阈值 80% 时标红提醒「接近阈值，建议导出备份」。
- 布局：版本号徽章挪到「AgentLink」标题之后；两个发送面板的「发送」按钮挪到文件/拖拽/目录控件下面。
- 默认阈值：活动文件 1 GB（`history.max_file_mb=1024`）或 7 天（`history.archive_days=7`）双触发滚动；
  导出为流式响应（多文件按行拼接、256 KiB 分块），大体积导出不吃服务端内存；
  后端另支持 `scope=archive:<文件名>` 单份归档导出。

## v0.4.14 发布物说明

- 界面：标题/顶栏带版本号；「发送」按钮合并文本+附件；支持 Ctrl+V 贴图、拖拽投递区、
  选择目录自动打包 `<目录名>.zip` 发送。
- 错误可见性：HTTP 非 2xx 不再被静默当作成功（v0.4.13 之前 >2 MiB 上传会显示 `{}` 且清空选择，
  看起来像「文件消失了」）。
- 上传体积上限跟随 `agentlink.json` 的 `files.max_file_size`（默认 100 MB）。
