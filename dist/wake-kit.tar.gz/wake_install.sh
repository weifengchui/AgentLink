#!/usr/bin/env bash
# wake_install.sh — AgentLink 桥"消息唤醒钩子"一键安装（WSL 侧，幂等）
# 作用：桥收到总线消息 → 自动 POST hermes webhook → 唤醒本机 agent 会话处理，
#       agent 不再需要自己记得拉收件箱。
set -e
DR=${AGENTLINK_BRIDGE_DIR:?用法: AGENTLINK_BRIDGE_DIR=<桥目录> AGENT_PROFILE=<profile> WEBHOOK_SECRET=*** bash wake_install.sh}
PROFILE=${AGENT_PROFILE:?需指定要唤醒的 hermes profile 名}
SECRET=${WEBH…CRET 来自 hermes -p $PROFILE webhook list}
PORT=${WEBHOOK_PORT:-8644}
AGENT=${BRIDGE_AGENT_ID:?桥的 agent 名（如 study/fanbot/liteguard）}

cd "$DR"
# 1) 钩子模块（与本脚本同目录的 wake_hook.py 拷入桥目录）
cp -f "$(dirname "$0")/wake_hook.py" ./wake_hook.py

# 2) wake.json
cat > wake.json <<EOF
{"url": "http://127.0.0.1:$PORT/webhooks/agentlink-msg", "secret": "$SECRET", "agent": "$AGENT", "skip_topics": []}
EOF

# 3) 若桥代码尚未内置 wake_hook 调用（新版 hermes_bridge/daemon 已内置），提示跳过
grep -q "wake_hook" hermes_bridge.py daemon.py 2>/dev/null || {
  echo "WARN: 本目录桥脚本不含 wake_hook 调用 —— 请用发布包里的新版 hermes_bridge.py/daemon.py 替换后重跑本脚本"; exit 1; }

# 4) 重启桥
if [ -f bridge.sh ]; then bash bridge.sh stop || true; bash bridge.sh start; fi
echo "OK: 唤醒钩子已就位（wake.json + wake_hook.py + 桥已重启）"
